function PlatformBadge({ platform }) {
    const config = {
        'tiktok': { label: 'TikTok' },
        'twitter': { label: 'X Thread' },
        'linkedin': { label: 'LinkedIn' },
        'instagram': { label: 'Instagram' },
        'newsletter': { label: 'Newsletter' }
    };

    const info = config[platform.toLowerCase()] || { label: platform };

    return (
        <span className="inline-flex items-center px-2 py-1 border border-gray-300 rounded text-xs text-gray-600 font-medium" data-name="platform-badge">
            {info.label}
        </span>
    );
}