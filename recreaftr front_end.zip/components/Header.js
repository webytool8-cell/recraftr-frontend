function Header({ user }) {
    const logo = getCurrentLogo();

    const handleNavigation = (path) => {
        window.location.href = path;
    };

    return (
        <header className="bg-[var(--bg-color)] border-b border-[var(--border-color)] sticky top-0 z-50 transition-colors duration-300" data-name="header">
            <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
                <div 
                    className="flex items-center gap-3 cursor-pointer group"
                    onClick={() => handleNavigation('index.html')}
                >
                    <img 
                        src={logo} 
                        alt="Logo"
                        className="w-10 h-10 object-contain transition-opacity duration-300"
                    />
                    <h1 className="text-2xl font-extrabold tracking-tight text-[var(--text-main)] select-none">
                        recraftr
                    </h1>
                </div>
                
                <nav className="flex items-center gap-6">
                    {!user && (
                        <div className="hidden md:flex items-center gap-6 text-sm text-[var(--text-main)]">
                            <a href="#how-it-works" className="hover:text-[var(--primary-color)] hover:underline transition-all decoration-1 underline-offset-4">How it Works</a>
                            <a href="#pricing" className="hover:text-[var(--primary-color)] hover:underline transition-all decoration-1 underline-offset-4">Pricing</a>
                        </div>
                    )}



                    {user ? (
                        <div className="flex items-center gap-4">
                            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-[var(--radius-full)] border border-[var(--border-color)] bg-[var(--surface-color)]">
                                {user.is_premium ? (
                                    <span className="flex items-center gap-1.5 text-xs font-bold text-[var(--primary-color)] uppercase tracking-wide">
                                        <div className="icon-sparkles w-3 h-3"></div>
                                        Member
                                    </span>
                                ) : (
                                    <>
                                        <span className="text-xs text-[var(--text-muted)]">Free</span>
                                        <button 
                                            onClick={() => handleNavigation('payment.html')}
                                            className="ml-2 text-[10px] font-bold text-[var(--bg-color)] bg-[var(--text-main)] px-2.5 py-1 rounded-[var(--radius-full)] hover:opacity-90 transition-opacity"
                                        >
                                            UPGRADE
                                        </button>
                                    </>
                                )}
                            </div>
                            
                            <button 
                                onClick={() => handleNavigation('profile.html')}
                                className="w-10 h-10 rounded-full border border-[var(--border-color)] overflow-hidden hover:border-[var(--text-main)] transition-colors"
                            >
                                <img src={user.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                            </button>
                        </div>
                    ) : (
                        <div className="flex items-center gap-4">
                             <button 
                                onClick={() => handleNavigation('login.html')}
                                className="btn btn-primary py-2.5 px-6 text-sm rounded-full bg-[var(--text-main)] text-[var(--bg-color)] hover:opacity-90 shadow-md"
                             >
                                Sign in
                             </button>
                        </div>
                    )}
                </nav>
            </div>
        </header>
    );
}