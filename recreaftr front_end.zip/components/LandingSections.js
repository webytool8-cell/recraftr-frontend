function FeatureGrid() {
    const features = [
        { title: 'Analysis', desc: 'Identifies hooks and core value props.' },
        { title: 'Repurposing', desc: 'Adapts content for threads and posts.' },
        { title: 'Formatting', desc: 'Optimized for readability and engagement.' }
    ];

    return (
        <section id="how-it-works" className="py-24 md:py-32 border-b border-[var(--border-color)] transition-colors duration-300">
            <div className="max-w-4xl mx-auto px-6">
                <h2 className="text-3xl md:text-4xl font-extrabold text-[var(--text-main)] mb-16 md:mb-20 tracking-tight">How it works</h2>
                <div className="grid md:grid-cols-3 gap-16 md:gap-12">
                    {features.map((f, i) => (
                        <div key={i} className="flex flex-col gap-3">
                            <h3 className="font-bold text-xl text-[var(--text-main)]">{f.title}</h3>
                            <p className="text-[var(--text-muted)] font-serif text-lg leading-relaxed">{f.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}

function UseCases() {
    return (
        <section className="py-24 md:py-32 bg-[var(--surface-color)] border-b border-[var(--border-color)] transition-colors duration-300">
            <div className="max-w-4xl mx-auto px-6 text-center">
                 <h2 className="text-3xl md:text-4xl font-extrabold text-[var(--text-main)] mb-8 tracking-tight">Designed for wordsmiths.</h2>
                 <p className="text-xl md:text-2xl text-[var(--text-muted)] font-serif max-w-2xl mx-auto leading-relaxed">
                     Whether you are writing a newsletter, a blog post, or a tweet, context matters. Recraftr understands the nuance.
                 </p>
            </div>
        </section>
    );
}

function PricingCompare() {
    return (
        <section id="pricing" className="py-24 md:py-32 transition-colors duration-300">
            <div className="max-w-4xl mx-auto px-6">
                <h2 className="text-3xl md:text-4xl font-extrabold text-[var(--text-main)] mb-16 md:mb-24 text-center tracking-tight">Membership</h2>
                
                <div className="grid md:grid-cols-2 gap-8 md:gap-12">
                    {/* Free */}
                    <div className="p-10 border border-[var(--border-color)] bg-[var(--surface-color)] rounded-2xl">
                        <div className="text-2xl font-bold mb-2 text-[var(--text-main)]">Free</div>
                        <div className="text-[var(--text-muted)] mb-8">For casual writers</div>
                        <div className="text-4xl font-bold mb-8 text-[var(--text-main)]">$0</div>
                        <ul className="space-y-3 mb-8 text-sm text-[var(--text-muted)]">
                            <li>5 operations per day</li>
                            <li>Standard processing</li>
                        </ul>
                        <a href="login.html" className="block w-full py-3 text-center border border-[var(--text-main)] text-[var(--text-main)] hover:bg-[var(--text-main)] hover:text-[var(--bg-color)] transition-all">Start Free</a>
                    </div>

                    {/* Pro */}
                    <div className="p-8 bg-[var(--text-main)] text-[var(--bg-color)]">
                        <div className="text-2xl font-bold font-serif mb-2">Member</div>
                        <div className="text-[var(--text-muted)] opacity-80 mb-8">For prolific creators</div>
                        <div className="text-4xl font-bold mb-8">$15<span className="text-lg opacity-60 font-normal">/mo</span></div>
                        <ul className="space-y-3 mb-8 text-sm opacity-80">
                            <li>Unlimited operations</li>
                            <li>Priority access</li>
                            <li>All formats</li>
                        </ul>
                        <a href="payment.html" className="block w-full py-3 text-center bg-[var(--bg-color)] text-[var(--text-main)] hover:opacity-90 transition-all font-bold">Become a Member</a>
                    </div>
                </div>
            </div>
        </section>
    );
}
