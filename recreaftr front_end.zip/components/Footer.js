function Footer() {
    return (
        <footer className="bg-[var(--bg-color)] border-t border-[var(--border-color)] py-16 text-sm text-[var(--text-muted)]" data-name="footer">
            <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-4 gap-10">
                <div className="col-span-1 md:col-span-2">
                    <h3 className="font-extrabold text-lg text-[var(--text-main)] mb-4">recraftr</h3>
                    <p className="max-w-xs mb-6 leading-relaxed">Intelligent content repurposing for writers. Turn one story into an entire distribution strategy.</p>
                    <div className="flex gap-4">
                        <a href="#" className="hover:text-[var(--primary-color)] transition-colors"><div className="icon-twitter w-5 h-5"></div></a>
                        <a href="#" className="hover:text-[var(--primary-color)] transition-colors"><div className="icon-github w-5 h-5"></div></a>
                    </div>
                </div>
                <div>
                    <h4 className="font-bold text-[var(--text-main)] mb-4">Product</h4>
                    <ul className="space-y-2">
                        <li><a href="#how-it-works" className="hover:text-[var(--primary-color)]">How it Works</a></li>
                        <li><a href="#pricing" className="hover:text-[var(--primary-color)]">Pricing</a></li>
                        <li><a href="login.html" className="hover:text-[var(--primary-color)]">Login</a></li>
                        <li><a href="payment.html" className="hover:text-[var(--primary-color)]">Upgrade</a></li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-bold text-[var(--text-main)] mb-4">Legal</h4>
                    <ul className="space-y-2">
                        <li><a href="#" className="hover:text-[var(--primary-color)]">Privacy Policy</a></li>
                        <li><a href="#" className="hover:text-[var(--primary-color)]">Terms of Service</a></li>
                        <li><a href="#" className="hover:text-[var(--primary-color)]">Cookie Policy</a></li>
                    </ul>
                </div>
            </div>
            <div className="max-w-6xl mx-auto px-6 mt-12 pt-8 border-t border-gray-100 text-center">
                 <p>&copy; {new Date().getFullYear()} recraftr. All rights reserved.</p>
            </div>
        </footer>
    );
}