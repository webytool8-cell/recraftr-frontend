function OutputPanel({ results, isProcessing }) {
    const [activeTab, setActiveTab] = React.useState(0);

    React.useEffect(() => {
        if (results && results.length > 0) setActiveTab(0);
    }, [results]);

    if (isProcessing) {
        return (
            <div className="flex flex-col items-center justify-center py-20">
                <div className="w-8 h-8 border-2 border-gray-200 border-t-black rounded-full animate-spin mb-4"></div>
                <p className="text-gray-500 font-serif italic">Refining your words...</p>
            </div>
        );
    }

    if (!results || results.length === 0) return null;

    const activeResult = results[activeTab];

    return (
        <div className="bg-[var(--surface-color)] border border-[var(--border-color)] shadow-sm rounded-lg overflow-hidden transition-colors duration-300" data-name="output-panel">
            {/* Minimal Tabs */}
            <div className="flex overflow-x-auto border-b border-[var(--border-color)]">
                {results.map((res, idx) => (
                    <button
                        key={idx}
                        onClick={() => setActiveTab(idx)}
                        className={`
                            px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors
                            ${activeTab === idx 
                                ? 'border-[var(--text-main)] text-[var(--text-main)]' 
                                : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-main)]'}
                        `}
                    >
                        {res.platform}
                    </button>
                ))}
            </div>

            {/* Content Area */}
            <div className="p-8">
                <div className="flex justify-end mb-4">
                     <CopyButton text={activeResult.content} />
                </div>
                <div className="relative">
                     <textarea 
                        className="w-full min-h-[500px] resize-none text-lg leading-relaxed text-[var(--text-main)] font-serif focus:outline-none bg-transparent"
                        value={activeResult.content}
                        onChange={(e) => { activeResult.content = e.target.value; }}
                    />
                </div>
            </div>
        </div>
    );
}

function CopyButton({ text }) {
    const [copied, setCopied] = React.useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <button 
            onClick={handleCopy}
            className={`
                text-sm transition-colors
                ${copied ? 'text-[var(--primary-color)] font-bold' : 'text-[var(--text-muted)] hover:text-[var(--text-main)]'}
            `}
        >
            {copied ? 'Copied to clipboard' : 'Copy text'}
        </button>
    );
}
