function InputPanel({ onRestructure, isProcessing }) {
    const [mode, setMode] = React.useState('text');
    const [content, setContent] = React.useState('');
    const [targets, setTargets] = React.useState({});
    const [tone, setTone] = React.useState('Editorial');

    const formats = [
        { id: 'newsletter', label: 'Newsletter', icon: 'mail' },
        { id: 'linkedin', label: 'LinkedIn', icon: 'linkedin' },
        { id: 'twitter', label: 'Thread', icon: 'twitter' },
        { id: 'instagram', label: 'Caption', icon: 'instagram' },
        { id: 'tiktok', label: 'Script', icon: 'video' }
    ];
    
    const tones = [
        'Editorial', 'Professional', 'Witty', 'Direct'
    ];

    const toggleTarget = (id) => {
        setTargets(prev => ({ ...prev, [id]: !prev[id] }));
    };

    const handleSubmit = () => {
        const selectedTargets = Object.keys(targets).filter(k => targets[k]);
        
        if (!content.trim()) return;

        let effectiveMode = mode;
        if (isValidUrl(content.trim())) {
            effectiveMode = content.includes('youtube.com') || content.includes('youtu.be') ? 'youtube' : 'article';
        }
        
        if (content.length > 20000) {
             alert('Please keep it under 20,000 characters.');
             return;
        }

        if (selectedTargets.length === 0) {
            alert('Please select at least one format.');
            return;
        }
        
        onRestructure(content, effectiveMode, selectedTargets, tone);
    };

    return (
        <div className="bg-[var(--bg-color)] transition-colors duration-300" data-name="input-panel">
            <div className="flex flex-col gap-12 md:gap-16">
                {/* 1. Input Area */}
                <div className="flex flex-col gap-6">
                    <label className="block font-sans text-2xl md:text-3xl font-extrabold text-[var(--text-main)] tracking-tight">
                        Tell your story.
                    </label>
                    <div className="relative group">
                        <div className="absolute top-0 left-0 w-1 h-full bg-[var(--border-color)] group-focus-within:bg-[var(--text-main)] transition-colors duration-300 rounded-full"></div>
                        <textarea
                            className="w-full min-h-[350px] resize-y font-serif text-lg md:text-xl leading-relaxed pl-8 py-4 focus:outline-none text-[var(--text-main)] placeholder:text-[var(--text-muted)] transition-colors bg-transparent"
                            placeholder="Paste your draft, notes, or a link..."
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                        ></textarea>
                    </div>
                </div>

                <div className="border-t border-gray-100 pt-10 md:pt-12">
                    <div className="grid md:grid-cols-2 gap-12 md:gap-20">
                        {/* 2. Format Selector */}
                        <div className="flex flex-col gap-5">
                            <label className="block text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] font-sans">
                                Output Format
                            </label>
                            <div className="flex flex-wrap gap-3 md:gap-4">
                                {formats.map(f => (
                                    <button
                                        key={f.id}
                                        onClick={() => toggleTarget(f.id)}
                                        className={`
                                            inline-flex items-center gap-2.5 px-5 py-3 md:py-2.5 rounded-full border transition-all text-sm font-semibold
                                            ${targets[f.id] 
                                                ? 'border-[var(--text-main)] bg-[var(--text-main)] text-[var(--bg-color)] shadow-md' 
                                                : 'border-[var(--border-color)] bg-white text-[var(--text-muted)] hover:border-[var(--text-main)] hover:text-[var(--text-main)]'}
                                        `}
                                    >
                                        <div className={`icon-${f.icon} text-base`}></div>
                                        {f.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* 3. Tone & CTA */}
                        <div className="flex flex-col gap-8 md:gap-10">
                            <div className="flex flex-col gap-5">
                                <label className="block text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] font-sans">
                                    Tone of Voice
                                </label>
                                <div className="flex flex-wrap gap-4">
                                    {tones.map(t => (
                                        <button
                                            key={t}
                                            onClick={() => setTone(t)}
                                            className={`
                                                px-2 py-1 text-base border-b-2 transition-all font-medium
                                                ${tone === t ? 'border-[var(--text-main)] text-[var(--text-main)]' : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-main)]'}
                                            `}
                                        >
                                            {t}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <button 
                                onClick={handleSubmit}
                                disabled={isProcessing || !content.trim()}
                                className="w-full md:w-auto self-start btn btn-primary rounded-full bg-[var(--primary-color)] text-[var(--primary-text)] hover:bg-[var(--primary-hover)] px-10 py-4 text-lg font-bold shadow-xl shadow-black/5"
                            >
                                {isProcessing ? 'Refining...' : 'Refine Draft'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}