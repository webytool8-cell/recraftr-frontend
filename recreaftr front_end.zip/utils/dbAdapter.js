/**
 * Database Adapter
 * Provides a safety layer over Trickle DB APIs.
 * Falls back to LocalStorage if the API is unavailable or returns HTML errors.
 */

const STORAGE_KEYS = {
    USER: 'recast_mock_user',
    HISTORY: 'recast_mock_history'
};

// Initialize Mock Data if needed
function getMockUser() {
    const stored = localStorage.getItem(STORAGE_KEYS.USER);
    if (stored) return JSON.parse(stored);
    
    // Default mock user
    const defaultUser = {
        objectId: 'mock-user-001',
        objectData: {
            name: 'Demo User (Offline)',
            email: 'demo@recast.ai',
            credits: 20,
            is_premium: false,
            avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
        }
    };
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(defaultUser));
    return defaultUser;
}

function getMockHistory() {
    const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return stored ? JSON.parse(stored) : [];
}

function saveMockUser(user) {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
}

function addMockHistory(item) {
    const history = getMockHistory();
    const newItem = {
        objectId: 'hist-' + Date.now(),
        createdAt: new Date().toISOString(),
        objectData: item
    };
    history.unshift(newItem); // Add to beginning
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
    return newItem;
}

// --- API Wrappers ---

async function safeListObjects(type, limit = 100, descent = true) {
    try {
        if (typeof trickleListObjects === 'function') {
            return await trickleListObjects(type, limit, descent);
        }
        throw new Error("Trickle API not defined");
    } catch (e) {
        console.warn(`[DB Adapter] API failed for list ${type}, using fallback.`, e);
        
        if (type === 'user') return { items: [getMockUser()] };
        if (type === 'usage_history') {
             // Return fallback history wrapped in object structure
             const history = getMockHistory().slice(0, limit);
             return { items: history };
        }
        return { items: [] };
    }
}

async function safeGetObject(type, id) {
    try {
        if (typeof trickleGetObject === 'function') {
            return await trickleGetObject(type, id);
        }
        throw new Error("Trickle API not defined");
    } catch (e) {
        console.warn(`[DB Adapter] API failed for get ${type} id=${id}, using fallback.`, e);
        
        if (type === 'user') {
            const mock = getMockUser();
            if (mock.objectId === id) return mock;
        }
        return null;
    }
}

async function safeCreateObject(type, data) {
    try {
        if (typeof trickleCreateObject === 'function') {
            return await trickleCreateObject(type, data);
        }
        throw new Error("Trickle API not defined");
    } catch (e) {
        console.warn(`[DB Adapter] API failed for create ${type}, using fallback.`, e);
        
        if (type === 'user') {
            const newUser = { objectId: 'mock-user-' + Date.now(), objectData: data };
            saveMockUser(newUser);
            return newUser;
        }
        if (type === 'usage_history') {
            return addMockHistory(data);
        }
        return { objectId: 'mock-' + Date.now(), objectData: data };
    }
}

async function safeUpdateObject(type, id, data) {
    try {
        if (typeof trickleUpdateObject === 'function') {
            return await trickleUpdateObject(type, id, data);
        }
        throw new Error("Trickle API not defined");
    } catch (e) {
        console.warn(`[DB Adapter] API failed for update ${type}, using fallback.`, e);
        
        if (type === 'user') {
            const currentUser = getMockUser();
            const updatedUser = { ...currentUser, objectData: { ...currentUser.objectData, ...data } };
            saveMockUser(updatedUser);
            return updatedUser;
        }
        return { objectId: id, objectData: data };
    }
}

/**
 * NEW: Calculate daily usage for free limits
 */
async function getDailyUsageCount(userId) {
    try {
        // Fetch recent history
        // Note: In real app with millions of rows, we'd filter by query.
        // For Trickle DB prototype, list 100 is usually enough to catch today's activity for a single user unless they spam.
        const res = await safeListObjects('usage_history', 100, true);
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

        const todaysActions = res.items.filter(item => {
            const itemDate = (item.createdAt || new Date().toISOString()).split('T')[0];
            return (
                item.objectData.user_id === userId &&
                item.objectData.action === 'restructure' &&
                itemDate === today
            );
        });
        
        return todaysActions.length;
    } catch (e) {
        console.error("Failed to count daily usage", e);
        return 0;
    }
}