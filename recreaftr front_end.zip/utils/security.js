/**
 * Security Utilities
 * Centralized validation and sanitization to prevent XSS and injection attacks.
 */

// Basic text sanitization to prevent XSS if data is ever used in HTML contexts
// Note: React escapes by default, but this is useful for API payloads or special rendering
function sanitizeText(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Strict URL validation to prevent javascript: or data: protocol attacks
function isValidUrl(url) {
    if (!url) return false;
    try {
        const parsed = new URL(url);
        // Only allow http and https protocols
        return ['http:', 'https:'].includes(parsed.protocol);
    } catch (e) {
        return false;
    }
}

// Limit string length to prevent payload size denial of service
function truncateInput(text, maxLength = 10000) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength);
}

// Validate basic email format
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}