/**
 * Auth Service
 * Handles user login, logout, and session management using Firebase + Trickle DB.
 */

const firebaseConfig = {
  apiKey: "AIzaSyAhJ0a9P17r63SdFbkMGtkOC_05DeLu77Q",
  authDomain: "recraftr-app.firebaseapp.com",
  projectId: "recraftr-app",
  storageBucket: "recraftr-app.firebasestorage.app",
  messagingSenderId: "824438760394",
  appId: "1:824438760394:web:02d7edb2195802a7d2e533",
  measurementId: "G-JZRDR9XCY5"
};

// Initialize Firebase
if (typeof firebase !== 'undefined' && !firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const AUTH_KEYS = {
    CURRENT_USER_ID: 'recast_current_user_id'
};

// --- Helper: Sync Firebase User with Trickle DB ---

async function syncUserWithDB(firebaseUser) {
    try {
        const email = firebaseUser.email;
        const name = firebaseUser.displayName || email.split('@')[0];
        const avatar = firebaseUser.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${name}`;

        // 1. Check if user exists in DB
        const allUsers = await safeListObjects('user', 100, true);
        let user = allUsers.items.find(u => u.objectData.email.toLowerCase() === email.toLowerCase());

        if (user) {
            // Update local session
            localStorage.setItem(AUTH_KEYS.CURRENT_USER_ID, user.objectId);
            return { ...user.objectData, id: user.objectId };
        } else {
            // 2. Create new user in DB
            const newUser = await safeCreateObject('user', {
                name: name,
                email: email,
                credits: 5, // Free starter credits
                is_premium: false,
                avatar_url: avatar
            });
            localStorage.setItem(AUTH_KEYS.CURRENT_USER_ID, newUser.objectId);
            return { ...newUser.objectData, id: newUser.objectId };
        }
    } catch (error) {
        console.error("Sync failed:", error);
        throw new Error("Failed to synchronize user data.");
    }
}

// --- Auth Methods ---

async function loginWithEmailAndPassword(email, password) {
    try {
        // Attempt Sign In
        const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
        return await syncUserWithDB(userCredential.user);
    } catch (error) {
        // If user not found, try to Create Account (Auto-registration flow for simplicity in this UI)
        if (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
            // Note: In a strict app, we should separate Login and Sign Up. 
            // For this seamless tool, we'll try to create if login fails, assuming the user meant to sign up.
            // BUT standard practice is explicit. Let's try to just return error and let UI handle "Sign Up" button?
            // User requested "Sign in option". Let's assume explicit action.
            throw error;
        }
        throw error;
    }
}

async function registerWithEmailAndPassword(email, password) {
    try {
        const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
        return await syncUserWithDB(userCredential.user);
    } catch (error) {
        throw error;
    }
}

async function loginWithGoogle() {
    const provider = new firebase.auth.GoogleAuthProvider();
    try {
        const result = await firebase.auth().signInWithPopup(provider);
        return await syncUserWithDB(result.user);
    } catch (error) {
        console.error("Google Login Error:", error);
        throw error;
    }
}

function logout() {
    firebase.auth().signOut().then(() => {
        localStorage.removeItem(AUTH_KEYS.CURRENT_USER_ID);
        window.location.href = 'login.html';
    });
}

async function getCurrentUser() {
    const userId = localStorage.getItem(AUTH_KEYS.CURRENT_USER_ID);
    if (!userId) {
        // Optional: Check if Firebase has a session but we lost local ID (e.g. cleared storage)
        // This requires waiting for onAuthStateChanged which is async.
        // For simplicity in this sync-like flow, we rely on the ID.
        return null;
    }
    
    try {
        const userObj = await safeGetObject('user', userId);
        if (userObj) {
            return { ...userObj.objectData, id: userObj.objectId };
        }
    } catch (error) {
        console.warn("Failed to get current user", error);
        localStorage.removeItem(AUTH_KEYS.CURRENT_USER_ID);
    }
    return null;
}