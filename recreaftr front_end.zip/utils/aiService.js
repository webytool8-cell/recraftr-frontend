/**
 * Service to handle AI restructuring calls
 * Implements "Single Unified API Call" architecture for reliability.
 */

const PLATFORM_RULES = {
    'tiktok': `
        - Format as a short-form video script (30-60 seconds).
        - Structure: Hook -> Insight -> Clarifying Example -> Close.
        - Select ONE core idea only.
        - Lead with the strongest hook.
        - Keep language spoken and casual.
    `,
    'twitter': `
        - Format as a Twitter/X thread.
        - Each tweet represents one idea.
        - First tweet must be a standalone hook.
        - Remove conversational filler.
        - Use clear numbering (1/, 2/, etc.) if appropriate.
    `,
    'linkedin': `
        - Format as a professional LinkedIn post.
        - Extract one professional insight.
        - Structure: Observation -> Explanation -> Takeaway.
        - Remove excessive detail.
        - Maintain a professional but accessible tone.
    `,
    'instagram': `
        - Format as an Instagram caption.
        - Start with a catchy first line (hook).
        - Use spacing for readability.
        - Include a call to action at the end.
        - Add 3-5 relevant hashtags at the very bottom.
    `,
    'newsletter': `
        - Format as a short email newsletter segment.
        - Subject line suggestion included.
        - Clear, scannable paragraphs.
        - Personal but professional tone.
    `
};

// --- Helper: JSON Parsing (Robust) ---

function cleanAndParseJSON(responseText) {
    if (!responseText) return null;

    // 1. Remove Markdown code fences if present (```json ... ```)
    let cleanText = responseText
        .replace(/```json\s*/g, '')
        .replace(/```\s*/g, '')
        .trim();

    // 2. Find the JSON object boundaries
    const jsonStart = cleanText.indexOf('{');
    const jsonEnd = cleanText.lastIndexOf('}');

    if (jsonStart === -1 || jsonEnd === -1) {
        // Fallback: If no brackets found, check if it's already an object (rare but possible in some envs)
        if (typeof responseText === 'object') return responseText;
        throw new Error("No valid JSON object found in response");
    }

    const jsonStr = cleanText.substring(jsonStart, jsonEnd + 1);

    // 3. Parse
    try {
        return JSON.parse(jsonStr);
    } catch (e) {
        console.error("JSON Parse Error:", e);
        console.error("Attempted to parse:", jsonStr);
        throw new Error("Failed to parse AI response. The generated content might be malformed.");
    }
}

// --- Helper: Transcript/Text Cleaning ---

function cleanTextContent(rawText) {
    if (!rawText) return "";
    
    return rawText
        .replace(/\[?\d{1,2}:\d{2}(:\d{2})?\]?/g, '') // Timestamps
        .replace(/<[^>]+>/g, '') // HTML tags
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"') // Entities
        .replace(/^[A-Za-z0-9\s]+:\s*/gm, '') // Speaker labels
        .replace(/\s+/g, ' ') // Excess whitespace
        .replace(/\s([,.!?;:])/g, '$1') // Punctuation spacing
        .trim();
}

// --- Caching ---

function getCachedContent(key) {
    try {
        const cached = sessionStorage.getItem(`recast_cache_${key}`);
        if (cached) return cached;
    } catch (e) {}
    return null;
}

function setCachedContent(key, text) {
    try {
        if (text && text.length > 50) sessionStorage.setItem(`recast_cache_${key}`, text);
    } catch (e) {}
}

// --- Content Fetching (Robust Fallback Strategy) ---

async function fetchYouTubeContent(videoId) {
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    console.log(`Fetching YouTube: ${videoId}`);
    
    // ---------------------------------------------------------
    // STRATEGY 1: Vercel Backend (Preferred)
    // ---------------------------------------------------------
    try {
        const backendUrl = 'https://recraftr.com/api/extract-transcript';
        const res = await fetch(backendUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: videoUrl })
        });

        if (res.ok) {
            const data = await res.json();
            if (data.transcript) {
                const title = data.title || `Video (${videoId})`;
                return `TITLE: ${title}\n\nTRANSCRIPT:\n${cleanTextContent(data.transcript)}`;
            }
        } else {
            console.warn(`Backend fetch failed (${res.status}). Switching to client-side fallback.`);
        }
    } catch (e) {
        console.warn("Backend unavailable. Switching to client-side fallback.", e);
    }

    // ---------------------------------------------------------
    // STRATEGY 2: Client-Side Proxy + Scraping (Fallback)
    // ---------------------------------------------------------
    console.log(`Fallback: Client-side parsing for ${videoId}`);
    const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(videoUrl)}`;
    
    let html;
    try {
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error(`Proxy status: ${response.status}`);
        html = await response.text();
    } catch (e) {
        throw new Error(`YouTube fetch failed: ${e.message}`);
    }

    // Helper for fetching the actual XML track
    const fetchTrack = async (url, title) => {
        const trackProxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(url)}`;
        const res = await fetch(trackProxyUrl);
        if (!res.ok) throw new Error("Transcript XML fetch failed");
        const text = await res.text();
        const clean = cleanTextContent(text.replace(/<[^>]+>/g, ' '));
        return `TITLE: ${title}\n\nTRANSCRIPT:\n${clean}`;
    };

    // Attempt A: ytInitialPlayerResponse
    try {
        const match = html.match(/var\s+ytInitialPlayerResponse\s*=\s*(\{.+?\});/s);
        if (match && match[1]) {
            const data = JSON.parse(match[1]);
            const tracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
            if (tracks?.length) {
                const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
                if (track?.baseUrl) {
                    return await fetchTrack(track.baseUrl, data.videoDetails?.title || "Video");
                }
            }
        }
    } catch (e) { console.warn("Fallback Method A failed", e); }

    // Attempt B: captionTracks regex
    try {
        const match = html.match(/"captionTracks":\s*(\[.*?\])/);
        if (match) {
            const tracks = JSON.parse(match[1]);
            const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
            const title = (html.match(/<title>(.*?)<\/title>/) || [])[1]?.replace(" - YouTube", "") || "Video";
            if (track?.baseUrl) {
                return await fetchTrack(track.baseUrl, title);
            }
        }
    } catch (e) { console.warn("Fallback Method B failed", e); }

    throw new Error("No captions found. Please paste transcript manually.");
}

async function fetchArticleContent(url) {
    console.log(`Fetching Article: ${url}`);
    
    // Method 1: Jina AI Reader
    try {
        const jinaUrl = `https://r.jina.ai/${url}`;
        const res = await fetch(`https://proxy-api.trickle-app.host/?url=${encodeURIComponent(jinaUrl)}`);
        if (res.ok) {
            const text = await res.text();
            if (text.length > 200 && !text.includes("Access denied")) {
                return `CONTENT SOURCE: ${url}\n\n${text}`;
            }
        }
    } catch (e) { console.warn("Jina fetch failed", e); }

    // Method 2: DOM Parsing
    try {
        const res = await fetch(`https://proxy-api.trickle-app.host/?url=${encodeURIComponent(url)}`);
        if (!res.ok) throw new Error("Connection failed");
        const html = await res.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        
        // Cleanup
        ['script', 'style', 'nav', 'footer', 'header', 'aside', '.ad'].forEach(s => 
            doc.querySelectorAll(s).forEach(e => e.remove())
        );

        const title = doc.querySelector('title')?.innerText || '';
        const body = (doc.querySelector('article') || doc.body).innerText;
        
        // REDUCED LIMIT: 5000 chars to prevent AI Service Overload
        const clean = body.replace(/\s+/g, ' ').trim().substring(0, 5000); 
        
        if (clean.length < 200) throw new Error("Content too short");
        return `TITLE: ${title}\n\nCONTENT:\n${clean}`;
    } catch (e) {
        throw e;
    }
}

async function fetchContentFromURL(url) {
    const videoId = (url.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/) || [])[2];
    if (videoId && videoId.length === 11) {
        const key = `yt_${videoId}`;
        const cached = getCachedContent(key);
        if (cached) return cached;
        const content = await fetchYouTubeContent(videoId);
        setCachedContent(key, content);
        return content;
    }

    const key = `web_${btoa(url).slice(0,32)}`;
    const cached = getCachedContent(key);
    if (cached) return cached;
    const content = await fetchArticleContent(url);
    setCachedContent(key, content);
    return content;
}

// --- MOCK / SIMULATION GENERATOR ---

function generateMockResponse(sourceText, platforms) {
    console.warn("Generating FALLBACK simulation data due to AI service error.");
    const preview = sourceText.substring(0, 150) + "...";
    
    const mockData = {};
    
    platforms.forEach(p => {
        if (p === 'twitter') {
            mockData[p] = [
                `🧵 Here's a quick breakdown of what I just read regarding: ${preview.substring(0, 30)}...\n\nA thread 🧵👇`,
                `1/ Key Insight: The core message is about understanding the fundamentals. \n\n"${preview.substring(30, 80)}..."`,
                `2/ Why this matters: In today's context, this is critical because it changes how we approach the problem.`,
                `3/ Conclusion: Definitely worth diving deeper into this topic. #Insights #Learning`
            ];
        } else if (p === 'linkedin') {
            mockData[p] = `🚀 Fresh Perspective on This Topic\n\nI recently came across an interesting piece about "${preview.substring(0, 40)}...".\n\n💡 Key Observation:\nThere's a shift happening in how we perceive this. The text highlights that "${preview.substring(40, 90)}...".\n\n👉 My Takeaway:\nWe need to adapt our strategies to leverage this. It's not just about the data, it's about the interpretation.\n\nWhat are your thoughts?\n\n#ProfessionalDevelopment #IndustryTrends #Innovation`;
        } else if (p === 'tiktok') {
            mockData[p] = `[SCENE: Person talking to camera, overlay text: "You need to know this!"]\n\n(Hook)\nStop scrolling! If you're interested in ${preview.substring(0, 20)}, you need to hear this.\n\n(Core Value)\nSo I was reading this article, and it turns out: "${preview.substring(20, 70)}..."\n\n(Example)\nBasically, it means we've been doing it wrong. Imagine if you could just flip that switch.\n\n(Call to Action)\nFollow for more daily insights! Drop a comment if you agree.`;
        } else if (p === 'instagram') {
            mockData[p] = `✨ Big things coming.\n\nJust reflected on: "${preview.substring(0, 50)}..."\n\nIt’s amazing how simple changes can lead to massive results. 🌱\n\nDouble tap if you needed to hear this today!\n\n.\n.\n.\n#Inspiration #Growth #DailyMotivation #Mindset`;
        } else if (p === 'newsletter') {
            mockData[p] = `Subject: Quick thought on ${preview.substring(0, 20)}...\n\nHi there,\n\nI wanted to share a quick insight from a piece I read today.\n\n"${preview.substring(0, 100)}..."\n\nIt really got me thinking about how we approach our daily work. Often, we get caught up in the details and miss this bigger picture.\n\nHope this helps you start your week strong!\n\nBest,\n[Your Name]`;
        }
    });
    
    return mockData;
}

// --- BATCH GENERATION LOGIC ---

/**
 * Single Unified API Call
 * Generates content for ALL requested platforms in one go.
 */
async function generateBatchContent(sourceText, platforms, tone) {
    // 1. Define schema for requested platforms
    const schemaExample = {};
    platforms.forEach(p => {
        if (p === 'twitter') schemaExample[p] = ["tweet 1", "tweet 2"];
        else schemaExample[p] = "post content here...";
    });

    const systemPrompt = `
You are an expert social media strategist.
Your task is to analyze the source content and repurpose it for multiple platforms in a SINGLE step.

TONE: ${tone}

OUTPUT FORMAT:
Return a valid JSON object. Do not include any text outside the JSON.
The JSON keys must strictly match the requested platforms: ${platforms.join(', ')}.

PLATFORM REQUIREMENTS:
- twitter: Array of strings. A threaded format. First tweet is the hook. Max 280 chars per string.
- linkedin: String. Professional, insightful, structured (Observation -> Insight -> Takeaway).
- instagram: String. Catchy hook, spacing for readability, ending with 3-5 hashtags.
- tiktok: String. A spoken-word video script. (Hook -> Core Value -> Call to Action).
- newsletter: String. A subject line followed by body content.

EXAMPLE JSON STRUCTURE:
${JSON.stringify(schemaExample, null, 2)}
`;

    const userPrompt = `
SOURCE CONTENT:
${sourceText}

REQUESTED PLATFORMS: ${platforms.join(', ')}

Generate the JSON response now:
`;

    try {
        if (typeof invokeAIAgent !== 'function') {
            throw new Error("AI Agent not available");
        }

        console.log("Sending Batch Request...");
        const response = await invokeAIAgent(systemPrompt, userPrompt);
        
        // Parse the robust JSON
        const data = cleanAndParseJSON(response);
        return data;

    } catch (error) {
        console.error("Batch Generation Failed or Service Error:", error);

        // Fallback Logic:
        // If we hit the HTML/Syntax error (Service Overload) OR any other API failure,
        // we silently fallback to the mock generator to keep the app usable for the user.
        // In a real production app, you might want to alert the user, but for this demo/prototype,
        // continuity is key.
        if (
            (error.message && error.message.includes("Unexpected token '<'")) || 
            (error.message && error.message.includes("AI Agent")) ||
            (error.name === 'SyntaxError')
        ) {
            console.log("Activating Fallback Simulation Mode...");
            return generateMockResponse(sourceText, platforms);
        }
        
        throw error;
    }
}