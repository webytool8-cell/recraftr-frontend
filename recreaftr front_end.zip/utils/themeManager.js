/**
 * Theme Manager
 * Handles Theme persistence.
 * Note: Dark mode has been removed. This file now enforces Light mode.
 */

const THEME_KEY = 'recraftr_theme';
// Logo for Light Mode (Dark text/elements)
const LOGO_FOR_LIGHT = 'https://app.trickle.so/storage/public/images/usr_19c684eaa8000001/76e7c87a-cc87-43fd-8019-acc4f81de36e.png';

function initTheme() {
    // Always enforce light mode
    const theme = 'light';
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
    return theme;
}

function toggleTheme() {
    // Disabled
    return 'light';
}

function getCurrentTheme() {
    return 'light';
}

function getCurrentLogo() {
    return LOGO_FOR_LIGHT;
}

// Initialize immediately
initTheme();