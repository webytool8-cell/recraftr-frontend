When handling AI Service errors:
- Watch for `SyntaxError: Unexpected token '<'` which usually indicates the AI service returned an HTML error page (500/502/504) instead of a JSON response.
- Gracefully catch this specific error and present a user-friendly message (e.g., "Service temporarily overloaded").
- Limit input payload sizes (e.g., max 8000-10000 chars) to reduce the risk of timeouts or payload limit errors from the AI provider.