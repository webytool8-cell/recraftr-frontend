When handling URL content extraction
- Understand that the AI agent has limited ability to scrape real-time websites or closed captions (like YouTube) without external tools.
- The "Fetch Content" step is a best-effort attempt.
- For major platforms (YouTube, Twitter), IMPLEMENT SPECIFIC PARSING LOGIC using raw HTML extraction where possible, rather than relying solely on generic AI summarization.
- If users complain about "not seeing video content", guide them to paste the transcript directly or implement a clearer fallback UI.