When updating the project
- Always check if the changes significantly affect the project structure or features.
- If they do, update `trickle/notes/README.md` to reflect the current state of the project.