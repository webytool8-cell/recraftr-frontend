When handling YouTube URLs:
- PRIORITY 1: Direct Page Parsing via `ytInitialPlayerResponse`.
  - Do not rely on simple regex for "captionTracks".
  - Extract the full `ytInitialPlayerResponse` JSON object from the HTML.
  - Navigate to `captions.playerCaptionsTracklistRenderer.captionTracks`.
  - This mimics the behavior of the standard `youtube-transcript-api` python library.
- PRIORITY 2: Public APIs (Piped, Invidious) as backup.
  - Rotate through multiple instances.
- CLEANING: Remove timestamps, HTML entities, and speaker tags.
- UX: If auto-fetch fails, prompt user explicitly to "Paste Transcript" rather than just showing a generic error.