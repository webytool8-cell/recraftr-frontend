When developing or updating features:

1. **Input Validation**:
   - ALWAYS validate URLs using `utils/security.js` before fetching.
   - REJECT `javascript:`, `data:`, or `file:` protocols.
   - Enforce character limits on all text inputs (e.g., max 20k chars for content).

2. **Payment Security**:
   - NEVER trust `amount` or `price` sent from the client-side.
   - Always define prices on the server-side or verify against a database product catalog.
   - Use Stripe Webhooks (in production) to verify payment success before granting access, rather than relying solely on client-side confirmation.

3. **Content Rendering**:
   - Avoid `dangerouslySetInnerHTML` in React unless absolutely necessary.
   - If used, sanitize content first using a library like DOMPurify (or internal `sanitizeText`).
   - Use `<textarea>` or `innerText` for displaying user-generated content where possible.

4. **API Usage**:
   - Do not expose private keys (like `STRIPE_SECRET_KEY` or `OPENAI_API_KEY`) in frontend code (`.js` files).
   - All external API calls requiring secrets must go through a proxy or backend server.