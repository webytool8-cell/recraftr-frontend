# Firebase Authentication Setup Guide

To integrate Firebase Sign-In into **recraftr**, follow these steps to generate the necessary credentials.

## Step 1: Create a Firebase Project
1. Go to the [Firebase Console](https://console.firebase.google.com/).
2. Click **"Add project"**.
3. Name your project (e.g., `recraftr-app`) and click **Continue**.
4. (Optional) Disable Google Analytics for now to save time, then click **Create project**.

## Step 2: Enable Authentication
1. Once your project is ready, select **Authentication** from the left sidebar (under "Build").
2. Click **"Get started"**.
3. In the **Sign-in method** tab, enable the providers you want:
   - **Google**: Click "Google", toggle "Enable", select a support email, and click "Save".
   - **Email/Password**: Click "Email/Password", toggle "Enable", and click "Save".

## Step 3: Register Your App
1. Click the **Gear icon** (Project Settings) in the top-left sidebar.
2. Scroll down to the **"Your apps"** section.
3. Click the **Web icon** (`</>`).
4. Enter an App nickname (e.g., `Recraftr Web`) and click **Register app**.

## Step 4: Get Configuration
1. After registering, you will see a code block labeled `const firebaseConfig = { ... }`.
2. It looks like this:
   ```javascript
   const firebaseConfig = {
     apiKey: "AIzaSy...",
     authDomain: "recraftr-app.firebaseapp.com",
     projectId: "recraftr-app",
     storageBucket: "recraftr-app.appspot.com",
     messagingSenderId: "...",
     appId: "..."
   };
   ```

## Step 5: Integration
**Copy that entire `firebaseConfig` object and send it to me in the chat.** 

I will then:
1. Update `utils/authService.js` to use Firebase instead of the mock system.
2. Ensure user data is synced between Firebase and our database.