# Trickle Frontend Update Guide for Recraftr

### Goal:
Make `https://recraftr.com` show your Trickle site and connect correctly to your live backend (`/api/create-payment-intent`)

---

## Step 1: Open your Trickle project
1. Log in to **Trickle**
2. Open your project (the one you want to deploy as Recraftr frontend)

---

## Step 2: Update API endpoints
1. Find all places in your Trickle project where you call the backend for payments or upgrades.
2. Replace any **preview URLs** with your **live backend URL**:

```diff
- fetch("https://trickle-preview-url.vercel.app/api/create-payment-intent", ...)
+ fetch("https://recraftr.com/api/create-payment-intent", ...)
```

3. Make sure every fetch / API call uses **HTTPS** and the **full domain**:
   * `https://recraftr.com/api/...`
4. Save your changes

> This ensures all payments go to your live backend.

---

## Step 3: Update frontend root links / assets (optional but recommended)
* If your Trickle project uses **relative paths** for assets, double-check:
  * Images, CSS, JS → use `/` relative paths or `https://recraftr.com/...` if needed
* This prevents missing assets when deployed

---

## Step 4: Publish / export frontend
1. In Trickle, click **Publish / Export**
2. Choose **Static build** (HTML, CSS, JS)
3. Export the build folder (`dist` or `build`)

> This is the folder you’ll deploy to Vercel.

---

## Step 5: Test locally (optional)
* You can use Trickle preview or a local static server:
```bash
npx serve build
```
* Open `http://localhost:5000` to verify:
  * Frontend loads
  * Buttons / API calls point to `https://recraftr.com`

> Don’t test using old preview URLs for payments — only live backend works for real charges

---

## Step 6: Deploy frontend to Vercel
1. Go to **Vercel → New Project → Import**
2. Select the Trickle build folder (`dist` or `build`)
3. Name it `recraftr-frontend`
4. Deploy

> After deployment, Vercel will give you a temporary URL (like `recraftr-frontend.vercel.app`)

---

## Step 7: Update domain to point to frontend
1. In **Vercel → Project → Domains**, add `recraftr.com`
2. Set it as **primary domain**
3. Enable **Force HTTPS**
4. Update **Hostinger DNS** to point `recraftr.com` → Vercel

> Once DNS propagates, visiting `https://recraftr.com` will show your Trickle frontend

---

## ✅ Step 8: Verify live frontend
1. Open `https://recraftr.com` → your Trickle frontend should appear
2. Click any upgrade / payment button → should trigger backend API call
3. Confirm Stripe payment works → check live Stripe Dashboard

---

**Key Trickle-specific points:**
* All **API calls must point to live backend**
* Always use **HTTPS full URLs**
* Exported build folder is what you deploy — don’t rely on previews for live payments
* Trickle previews are **only for testing UI**, not for real Stripe integration