# Migration Guide: Moving to Hostinger or External Hosting

Since this project is built as a static web application (HTML/CSS/JS), it can be hosted on any standard web host like Hostinger, Netlify, or Vercel. However, because it relies on Trickle's internal infrastructure for the Database and AI, there are important limitations to understand.

## How to Migrate

1. **Download Files**: Export all project files (`.html`, `.js`, `.css`, and folders).
2. **Upload to Hostinger**:
   - Access your Hostinger File Manager or use FTP.
   - Upload the files to the `public_html` directory.
   - Ensure `index.html` is in the root of `public_html`.

## Feature Limitations on External Hosting

When running outside of the Trickle environment, the "Backend" features will behave differently:

### 1. Database (User Accounts & Credits)
- **On Trickle**: Uses the Cloud Database. Data is persistent and secure.
- **On Hostinger**: The app will automatically detect it is offline and fall back to **LocalStorage**.
  - **Impact**: User accounts, credits, and history will only be saved on the visitor's specific browser/device. If they clear cookies or switch devices, their data is lost.
  - **Fix**: To have a real database on Hostinger, you would need to integrate a third-party backend like Firebase or Supabase and update `utils/dbAdapter.js`.

### 2. AI Content Generation
- **On Trickle**: Uses the built-in `invokeAIAgent` for unlimited, free AI generation.
- **On Hostinger**: This function will not exist.
  - **Impact**: The app is designed to handle this gracefully. It will switch to **"Simulation Mode"**, returning pre-written mock content instead of generating new AI text.
  - **Fix**: You would need to sign up for an API key (e.g., OpenAI, Anthropic) and update `utils/aiService.js` to call that API directly (or via a proxy server you build).

## Recommendation

For a fully functional app with zero configuration, keeping it on **Trickle** is recommended. If you must move to Hostinger, treat the current codebase as a "Static Demo" that requires backend integration work to become fully functional.