# recraftr

A calm, intelligent content restructuring tool that takes articles, webpages, or text and adapts them for social media platforms using AI.

## Features
- **Article Extraction**: Automatically fetches and cleans content from blog posts and news sites.
- **YouTube Extraction (Beta)**: Attempts to fetch transcripts from videos.
- **Multi-Platform Output**: Generates native content for X/Twitter, LinkedIn, Newsletter, etc.
- **Tone Selection**: Customize the voice of the output.
- **Subscription Model**: 
    - Free Plan: 5 restructures per day.
    - Creator Plan ($15/mo): Unlimited access.
- **Payment Integration**: Mock Stripe checkout simulation.

## Structure
- `index.html`: Entry point.
- `app.js`: Main application logic.
- `components/`: UI components (InputPanel, OutputPanel, etc.).
- `utils/`: 
    - `aiService.js`: Handles scraping and LLM prompts.
    - `authService.js`: User management.
    - `dbAdapter.js`: Database abstraction.