const express = require("express");
const app = express();
const cors = require("cors");

// --- Configuration Check ---
if (!process.env.STRIPE_SECRET_KEY) {
    console.error("CRITICAL ERROR: STRIPE_SECRET_KEY environment variable is missing.");
    console.error("Please add it to your Vercel Project Settings or .env file.");
}

// Initialize Stripe with safe fallback to avoid startup crash, 
// but requests will fail if key is missing (as expected)
const stripeKey = process.env.STRIPE_SECRET_KEY || "sk_test_placeholder_key_missing";
const stripe = require("stripe")(stripeKey);

app.use(express.static("public"));
app.use(express.json());
app.use(cors());

// Health check endpoint
app.get("/", (req, res) => {
  res.send({ 
      status: "Running", 
      configured: !!process.env.STRIPE_SECRET_KEY 
  });
});

// --- Helper Function for Transcript Extraction ---
function cleanTextContent(text) {
    return text
        .replace(/&amp;#39;/g, "'")
        .replace(/&amp;quot;/g, '"')
        .replace(/&amp;/g, '&')
        .replace(/&#39;/g, "'")
        .replace(/\n/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

app.post("/api/extract-transcript", async (req, res) => {
    try {
        const { url } = req.body;
        if (!url) {
            return res.status(400).json({ error: "URL is required" });
        }

        console.log(`Fetching transcript for: ${url}`);

        // 1. Fetch the YouTube Video Page
        // We act like a browser to get the full HTML with hydration data
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        if (!response.ok) {
            throw new Error(`YouTube page fetch failed: ${response.status}`);
        }

        const html = await response.text();

        // 2. Extract Captions Logic (Server-Side)
        let captionUrl = null;
        let videoTitle = "YouTube Video";

        // Attempt A: ytInitialPlayerResponse (Most reliable)
        try {
            const match = html.match(/var\s+ytInitialPlayerResponse\s*=\s*(\{.+?\});/s);
            if (match && match[1]) {
                const data = JSON.parse(match[1]);
                videoTitle = data.videoDetails?.title || videoTitle;
                
                const tracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
                if (tracks && tracks.length) {
                    // Prefer English, fallback to first
                    const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
                    captionUrl = track.baseUrl;
                }
            }
        } catch (e) {
            console.warn("Strategy A failed:", e.message);
        }

        // Attempt B: captionTracks regex (Fallback)
        if (!captionUrl) {
            try {
                const match = html.match(/"captionTracks":\s*(\[.*?\])/);
                if (match && match[1]) {
                    const tracks = JSON.parse(match[1]);
                    const track = tracks.find(t => t.languageCode === 'en') || tracks[0];
                    captionUrl = track.baseUrl;
                }
            } catch (e) {
                console.warn("Strategy B failed:", e.message);
            }
        }

        if (!captionUrl) {
            return res.status(404).json({ error: "No captions found for this video." });
        }

        // 3. Fetch the actual transcript XML/JSON
        const transcriptResponse = await fetch(captionUrl);
        const transcriptText = await transcriptResponse.text();

        // 4. Clean formatting (Remove XML tags like <text>)
        // Simple Regex to strip tags:
        const cleanTranscript = cleanTextContent(transcriptText.replace(/<[^>]+>/g, ' '));

        return res.json({
            title: videoTitle,
            transcript: cleanTranscript
        });

    } catch (error) {
        console.error("Transcript Error:", error);
        return res.status(500).json({ error: error.message || "Internal Server Error" });
    }
});

app.post("/api/create-payment-intent", async (req, res) => {
  try {
    // SECURITY: Do NOT accept amount from the client.
    // Always look up prices on the server to prevent price tampering.
    // For this app, we have a fixed price of $15.00 for the Creator Plan.
    const FIXED_PRICE_AMOUNT = 1500; // $15.00 USD
    
    // Validation
    if (!process.env.STRIPE_SECRET_KEY) {
        throw new Error("Server Misconfiguration: You did not provide an API key (STRIPE_SECRET_KEY) in environment variables.");
    }

    // Create a PaymentIntent with the secure server-side amount
    const paymentIntent = await stripe.paymentIntents.create({
      amount: FIXED_PRICE_AMOUNT,
      currency: "usd",
      automatic_payment_methods: {
        enabled: true,
      },
      // Metadata helps track what this payment is for
      metadata: {
          product: 'Creator Plan',
          environment: process.env.NODE_ENV || 'development'
      }
    });

    res.send({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    console.error("Error creating payment intent:", error);
    // Send specific error message to frontend
    res.status(500).send({ error: error.message });
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Node server listening on port ${PORT}!`));