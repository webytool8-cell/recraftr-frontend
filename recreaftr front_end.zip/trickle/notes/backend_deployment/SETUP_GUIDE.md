# Vercel + Stripe Backend Setup Guide

This folder contains the 3 files you need to create a secure backend for your payment system.

## Step 1: Create Files Locally
Create a folder on your computer named `recraftr-backend` and create these three files inside it using the code provided in this folder:
1. `server.js`
2. `package.json`
3. `vercel.json`

## Step 2: Push to GitHub
1. Go to [GitHub.com](https://github.com) and create a new repository (e.g., `recraftr-payments`).
2. Upload these 3 files to that repository.

## Step 3: Deploy to Vercel
1. Go to [Vercel.com](https://vercel.com) -> **Add New Project**.
2. Select "Import" next to your `recraftr-payments` repository.
3. In the **Configure Project** screen, look for **Environment Variables**.
4. Add a new variable:
   - **Name**: `STRIPE_SECRET_KEY`
   - **Value**: `sk_test_...` (Copy this from your Stripe Dashboard)
5. Click **Deploy**.

## Step 4: Get Your URL
Once deployed, Vercel will give you a domain (e.g., `https://recraftr-payments.vercel.app`).
- Your API Endpoint will be: `https://recraftr-payments.vercel.app/api/create-payment-intent`

## Step 5: Tell Trickle
Come back to the chat and paste that URL!