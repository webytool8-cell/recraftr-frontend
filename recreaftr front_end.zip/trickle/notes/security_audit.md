# Security Audit & Improvements

**Date**: January 25, 2026
**Status**: Hardened

## 1. Payment Security (Critical)
- **Vulnerability**: The previous backend simulation allowed the client to specify the payment amount (`req.body.amount`). A malicious user could send a request with `{ amount: 1 }` to get a subscription for $0.01.
- **Fix**: Updated `server.js` to ignore the client-provided amount. The price is now hardcoded to `$15.00` (1500 cents) on the server side.

## 2. Input Sanitization
- **Vulnerability**: Potential for malicious URL schemes (e.g., `javascript:alert(1)`) or massive payload DoS attacks.
- **Fix**: 
  - Created `utils/security.js` with `isValidUrl`, `sanitizeText`, and `truncateInput`.
  - Updated `InputPanel.js` to validate that inputs are strictly `http/https` URLs before processing.
  - Enforced a 20,000 character limit on text inputs to prevent browser hanging or API abuse.

## 3. XSS Prevention
- **Status**: The app primarily uses React's default data binding (`{value}`), which automatically escapes content. 
- **Check**: Verified no instances of `dangerouslySetInnerHTML` are used with user input.
- **Output**: The output panel uses a `<textarea>`, which renders content as plain text, nullifying HTML injection risks.

## 4. API Keys
- **Status**: 
  - `STRIPE_PUBLISHABLE_KEY`: Public by design (Safe).
  - `FIREBASE_CONFIG`: Public by design (Safe, relies on Firestore Rules).
  - `STRIPE_SECRET_KEY`: Kept on server-side only (Safe).
  
## Next Steps (For Production)
- **Firestore Rules**: Ensure database rules restrict writes to `usage_history` and `user` tables to the authenticated user only.
- **Content Security Policy (CSP)**: Implement strict CSP headers on the hosting provider (Netlify/Vercel) to restrict script sources to trusted domains only.